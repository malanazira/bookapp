class ProductBookapp {

  static List artikel = [
    {"image" : "https://www.ikapi.org/wp-content/uploads/2023/03/Launch-IIBF-2023-1-1080x675.jpg"},
    {"image" : "https://library.uin-malang.ac.id/wp-content/uploads/2023/08/WEBSITE-2-e1693122891781-2048x747.png"},
    {"image" : "https://library.uin-malang.ac.id/wp-content/uploads/2023/09/BEDAH-BUKU-LP2M-UIN-MALANG-2048x1024.png"}
  ];
//The Book That Helped Me Overcome the Good Child Syndrome as an Adult

  static List display1 = [
    {
      "photo" : "https://cdn.gramedia.com/uploads/items/9786020324784_Hujan-Cover-Baru-2018.jpg",
      "autor" : "Tere Liye",
      "title" : "Hujan",
      "rate" : "4.8"
    },

    {
      "photo" : "https://th.bing.com/th/id/OIP.N47nvI5m1bZilWOmict9bQHaLe?pid=ImgDet&w=661&h=1024&rs=1",
      "autor" : "James Clear",
      "title" : "Atomic Habits",
      "rate"  : "4.9"
    },

    {
      "photo" : "https://th.bing.com/th/id/OIP.ksSZcQsVY1Qg11pHA8_-6gHaLM?pid=ImgDet&rs=1",
      "autor" : "Matt Haig",
      "title" : "Midnight Library",
      "rate"  : "4.7"
    },

  ];

  

  static List display2 = [

    {
      "photo" : "https://www.bukukita.com/babacms/displaybuku/105261_f.jpg",
      "autor" : "Leila S Chudori",
      "title" : "Laut Bercerita",
      "rate"  : "4.8"
    },

    {
      "photo" : "https://th.bing.com/th/id/OIP.fYs_bsL19BAKdDGZprmkzQHaJ4?pid=ImgDet&rs=1",
      "autor" : "R F Kuang",
      "title" : "The Dragon Repubic",
      "rate"  : "4.7"
    },

    {
      "photo" : "https://inc.mizanstore.com/aassets/img/com_cart/produk/_2023.jpg",
      "autor" : "Tere Liye",
      "title" : "Hello",
      "rate"  : "4.8"
    },

  ];

  static List categori1 = [
    {
      "photo" : "https://cdn.gramedia.com/uploads/items/9786020324784_Hujan-Cover-Baru-2018.jpg",
      "autor" : "Tere Liye",
      "title" : "Hujan",
      "rate" : "4.8"
    },

    {
      "photo" : "https://th.bing.com/th/id/OIP.N47nvI5m1bZilWOmict9bQHaLe?pid=ImgDet&w=661&h=1024&rs=1",
      "autor" : "James Clear",
      "title" : "Atomic Habits",
      "rate"  : "4.9"
    },

    {
      "photo" : "https://th.bing.com/th/id/OIP.ksSZcQsVY1Qg11pHA8_-6gHaLM?pid=ImgDet&rs=1",
      "autor" : "Matt Haig",
      "title" : "Midnight Library",
      "rate"  : "4.7"
    },

    {
      "photo" : "https://ebooks.gramedia.com/ebook-covers/45496/image_highres/ID_FITE2018MTH12.jpg",
      "autor" : "Henry Manampiring",
      "title" : "Filosofi Teras",
      "rate"  : "4.8"
    },

     {
      "photo" : "https://th.bing.com/th/id/OIP.FKdNCN2v5MXr88atv_O98QHaJ4?pid=ImgDet&rs=1",
      "autor" : "Tere Liye",
      "title" : "RIndu",
      "rate"  : "4.8"
    },

    {
      "photo" : "https://i.thenile.io/r1000/9781634502535.jpg?r=5eab20cf2196d",
      "autor" : "Napoleon Hill",
      "title" : "Think and Grow Rich",
      "rate"  : "4.8"
    },
    
    {
      "photo" : "https://1.bp.blogspot.com/-DSYRuFFQo_Q/WkciRmb49hI/AAAAAAAAFSI/W5Mzyy33VGkEb0Xntxk9cimBodULoV-cQCLcBGAs/s1600/cover-novel-bintang-karya-tere-liye.jpg",
      "autor" : "Tere Liye",
      "title" : "Bintang",
      "rate"  : "4.8"
    },

    {
      "photo" : "https://3.bp.blogspot.com/-1JAOjxXykLM/VfGwbrx29ZI/AAAAAAAABsE/zXHfqF1b0ts/s1600/dilan-2-5588d079df720.jpg",
      "autor" : "Pidi Baiq",
      "title" : "Dilan 2",
      "rate"  : "4.8"
    },

    {
      "photo" : "https://cdn.gramedia.com/uploads/items/9789797809324_kata.jpg",
      "autor" : "Rintik Sedu",
      "title" : "Kata",
      "rate"  : "4.8"
    },

    {
      "photo" : "https://www.bukukita.com/babacms/displaybuku/106484_f.jpg",
      "autor" : "Fiersa Besari",
      "title" : "Arah Langkah",
      "rate"  : "4.8"
    },

    {
      "photo" : "https://th.bing.com/th/id/OIP.w1K485iMlOBzKoGcNR-dWwAAAA?pid=ImgDet&rs=1",
      "autor" : "Morgan Housel",
      "title" : "Pshycology of Money",
      "rate"  : "4.8"
    },

    {
      "photo" : "https://pbs.twimg.com/media/FeEcwbxVUAAC31U.jpg",
      "autor" : "Brian Khrisna",
      "title" : "Kudasai",
      "rate"  : "4.8"
    },




    











  ];




}